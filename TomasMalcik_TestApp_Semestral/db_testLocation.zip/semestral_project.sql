-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Počítač: 127.0.0.1
-- Vytvořeno: Stř 27. kvě 2020, 17:41
-- Verze serveru: 10.4.6-MariaDB
-- Verze PHP: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `semestral_project`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `results`
--

CREATE TABLE `results` (
  `idR` int(11) NOT NULL,
  `studentNum` char(12) COLLATE utf8_czech_ci NOT NULL,
  `testName` char(70) COLLATE utf8_czech_ci NOT NULL,
  `percentage` double NOT NULL,
  `timer` bigint(20) NOT NULL,
  `testDate` varchar(255) COLLATE utf8_czech_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `results`
--

INSERT INTO `results` (`idR`, `studentNum`, `testName`, `percentage`, `timer`, `testDate`) VALUES
(1, 'M19000059', 'test1', 0, 13654, '2020-05-24'),
(2, 'M19000058', 'test1', 0, 11684, '2020-05-24'),
(3, 'M19000060', 'test1', 0, 2308, '2020-05-24'),
(4, 'O19000059', 'test1', 0, 1771, '2020-05-24'),
(5, 'M19000059', 'test1', 16.666666666666664, 12830, '2020-05-25'),
(6, 'M19000059', 'test1', 0, 2624, '2020-05-25'),
(7, 'M19000059', 'test1', 0, 3714, '2020-05-25'),
(8, 'M19000059', 'test1', 16.666666666666664, 49244, '2020-05-25'),
(9, 'M19000059', 'test1', 0, 20273, '2020-05-25'),
(10, 'M19000059', 'test1', 0, 10071, '2020-05-26'),
(11, 'M19000059', 'test1', 33.33333333333333, 50259, '2020-05-27'),
(12, 'M19000059', 'test1', 50, 11603, '2020-05-27'),
(13, 'M19000059', 'test1', 16.666666666666664, 6540, '2020-05-27'),
(14, 'M19000059', 'test1', 33.33333333333333, 7505, '2020-05-27'),
(15, 'M19000059', 'test1', 33.33333333333333, 7121, '2020-05-27'),
(16, 'M19000059', 'test1', 0, 2427, '2020-05-27'),
(17, 'M19000059', 'test1', 0, 3191, '2020-05-27'),
(18, 'M19000059', 'test1', 16.666666666666664, 8864, '2020-05-27'),
(19, 'M19000059', 'test1', 0, 2646, '2020-05-27'),
(20, 'M19000059', 'test1', 0, 2646, '2020-05-27'),
(21, 'M19000059', 'test1', 0, 3326, '2020-05-27');

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`idR`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `results`
--
ALTER TABLE `results`
  MODIFY `idR` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
